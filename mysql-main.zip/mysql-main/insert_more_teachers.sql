insert into lecturers (last_name, first_name, degree) values
('Benedict', 'Harold', 'BSc.'),
('Beverly', 'Small', 'BSc.'),
('Henry', 'Osbourne', 'MSc.'),
('Reid', 'Wilson', 'BSc.'),
('William', 'Cumberbatch', 'PhD.'),
('Smith', 'Campbell', 'BSc.'),
('Aura', 'Alex', 'PhD.')
