/*
	This is how you remove a database. Be verrrrry deliberate.
*/

drop database school_db1;