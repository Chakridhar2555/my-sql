use school_db;

insert into school_db.courses (title, number_of_credits, course_code) values
('Data Mining',3,'CS105')
,('Introduction to SQL',3,'CS106')
,('Introduction to C++',3,'CS107')
,('Website Development',3,'CS108')
,('Internet Authoring',3,'CS109')
,('Artificial Intelligence',3,'CS110')