-- This command is creating a database

CREATE DATABASE school_db2;