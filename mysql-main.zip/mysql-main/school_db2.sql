-- This Command is used for creating database 


CREATE database school_db2;
